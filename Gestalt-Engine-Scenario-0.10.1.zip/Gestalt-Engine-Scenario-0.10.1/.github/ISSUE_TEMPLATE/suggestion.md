---
name: Suggestion
about: If you don't want to use discord or steam, this is the next best option!
title: "[Suggestion]:"
labels: enhancement
assignees: ''

---

**Suummary**

**Indepth Explanation of idea**

**Reasoning**
