# Rimworld Extended: Properly

A mod adding many features (primarilly genes right now, both 100% of my own design (albiet with frameworks), and based on/ adding onto other mods!), all of them designed to mesh well with vanilla.

It also has cross compatibility with other mods, for two reasons:
  1. to allow this mod to fit along with other mods better
  2. to line other mods, subtly shifting them so they are "angled" more twords vanilla. Then features added by my mod bridge the gap, makeing those mods fit in much better, while bareley changeing things!
