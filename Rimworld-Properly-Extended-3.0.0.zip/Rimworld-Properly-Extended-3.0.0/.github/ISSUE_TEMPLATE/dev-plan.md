---
name: Dev Plan
about: An admin-only (hopefuly I can hide it) preset for making a checklist of project
  plans, such as miscilaneus featires that dont really need their own issue
title: ''
labels: enhancement
assignees: ''

---


